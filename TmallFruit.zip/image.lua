--TmallFruit
--image.lua

-- Create By TouchSpriteStudio on 11:16:09
-- Copyright © TouchSpriteStudio . All rights reserved.

	
require"TSLib"
ret = imageBinaryzation("__encrypt__立即去收.png")	
dialog(ret)
